from django.apps import AppConfig


class DonorConfig(AppConfig):
    name = 'donor'
